﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class PlayerMovementScript2 : MonoBehaviour
{
    public float speed;
    public Rigidbody playerRigidbody;
    public ScoreScript scoreScript;
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        if (scoreScript.score >= scoreScript.maxscore)
        {
            SceneManager.LoadScene("GameWin");
        }
    }
    void FixedUpdate()
    {
        float MoveHorizontal = Input.GetAxis("Horizontal");
        float MoveVertical = Input.GetAxis("Vertical");
        Vector3 movement = new Vector3(MoveHorizontal, 0, MoveVertical);
        transform.Translate(movement * Time.deltaTime * speed);
    }
    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == ("Coin"))
        {
            scoreScript.score++;
            Destroy(other.gameObject);
        }

    }
    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.tag == ("FireWall"))
        {
            SceneManager.LoadScene("GameLose");
        }
    }
}
